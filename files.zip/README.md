# Excel Master & Template Exporter - Version 5.0+

> Advanced Excel generation with **Automatic Version Management**, **Git Integration**, and **One-Click Deployment**

![Version](https://img.shields.io/badge/Version-5.0%2B-blue)
![Status](https://img.shields.io/badge/Status-Production%20Ready-green)
![Python](https://img.shields.io/badge/Python-3.8%2B-blue)
![License](https://img.shields.io/badge/License-Proprietary-red)

---

## 🌟 What's New in v5.0+

### ✨ New Features

- **🔢 Automatic Version Management**: Versions auto-increment based on changes
- **🚀 One-Click Git Deploy**: Pull code and restart with single click
- **📊 Real-Time Changelog**: Every action tracked with timestamp and type
- **🔍 Change Detection**: SHA256 hashing to detect file modifications
- **🛠️ Admin Control Panel**: Dedicated deployment operations dashboard
- **📈 Version History**: See exactly what changed and when

### 📋 How Versioning Works

The application monitors three key files and auto-increments version accordingly:

```
app.py modified         → MAJOR.MINOR.0.1  (5.0.0 → 5.1.0)
Templates changed       → MAJOR.MINOR.PATCH.1  (5.1.0 → 5.1.1)
Custom config changed   → MAJOR.MINOR.PATCH.1  (5.1.1 → 5.1.2)
Every run              → BUILD increments  (5.1.2.5 → 5.1.2.6)
```

---

## 📦 Installation

### Prerequisites
```bash
Python 3.8 or higher
pip (Python package manager)
git (for repository management)
```

### Step 1: Clone or Download
```bash
cd your-project-directory
# Files: app.py, version.json, changelog.json, etc.
```

### Step 2: Install Dependencies
```bash
pip install streamlit pandas openpyxl numpy
```

### Step 3: Make Service Script Executable
```bash
chmod +x streamlit_service.sh
```

### Step 4: First Run
```bash
# Option A: Direct
streamlit run app.py

# Option B: Via service manager
./streamlit_service.sh start

# Option C: Custom port
streamlit run app.py --server.port 8502
```

### Step 5: Access Application
```
🌐 http://localhost:8501
📝 Username: admin
🔐 Password: PaSSw0rd@1
```

⚠️ **Change credentials before production!**

---

## 🎯 Core Features

### 1. Excel Generation
- ✅ Create master files from source
- ✅ Generate multiple sheets with filters
- ✅ Combined workbooks (all sheets)
- ✅ Separate files (individual sheets)
- ✅ Professional formatting & styling
- ✅ Subtotals & grouping
- ✅ Date sorting & filtering

### 2. Template Management
- ✅ 10+ default templates
- ✅ Edit filter rules
- ✅ Enable/disable templates
- ✅ Custom descriptions
- ✅ Persistent configuration

### 3. Version Management
- ✅ Auto-increment on changes
- ✅ File hash tracking (SHA256)
- ✅ Creation timestamps
- ✅ Last modified tracking
- ✅ Git commit linkage

### 4. Change Tracking
- ✅ Detailed changelog (100 entries)
- ✅ Type categorization (code_update, config_update, etc.)
- ✅ Timestamp for each change
- ✅ User attribution
- ✅ Change descriptions

### 5. Git Integration
- ✅ Pull from remote repository
- ✅ Push local changes
- ✅ Branch switching
- ✅ Commit tracking
- ✅ Status monitoring

### 6. Deployment Control
- ✅ Pull + Restart (one-click deploy)
- ✅ Pull only (non-disruptive)
- ✅ Restart only (emergency fix)
- ✅ Push to GitHub (backup)

---

## 📱 User Interface

### 📁 Tab 1: Export
- Generate master files
- Configure data source
- Download Excel workbooks
- Filter and sort options

### ⚙️ Tab 2: Templates
- Edit sheet templates
- Modify filter rules
- Enable/disable sheets
- View configurations

### 📋 Tab 3: Custom
- Create custom templates
- Select specific columns
- Manage custom exports

### 🛠️ Tab 4: Admin & Deploy
**Left Panel: Operations**
```
🔄 Git Pull + Streamlit Restart
   └─ Full production deployment
   
📥 Git Pull Only
   └─ Update code silently
   
🔁 Restart Streamlit Only
   └─ Emergency restart
   
📤 Push to GitHub
   └─ Backup configuration
```

**Right Panel: Status**
```
Version Information
├─ Current version
├─ Build number
├─ Creation date
└─ Last modified date

Repository Status
├─ Current branch
├─ Commit hash
└─ Changes pending (if any)

Changelog (Last 10)
├─ Type emoji
├─ Description
└─ Timestamp
```

---

## 🔄 Deployment Workflow

### Scenario 1: Deploy Code Changes
```
1. Edit app.py (add feature)
   └─ Auto-detected on next run
   
2. Version: 5.0.0.1 → 5.1.0.1
   └─ MINOR incremented, PATCH reset
   
3. Go to Admin & Deploy tab
   
4. Click "🔄 Git Pull + Streamlit Restart"
   └─ Code updated to production
   └─ App restarted automatically
   
5. Version: 5.1.0.1 → 5.1.0.2
   └─ Logged as "git_pull_restart"
```

### Scenario 2: Template Configuration Update
```
1. Edit template in ⚙️ Templates tab
   
2. Click "Save Changes"
   └─ Version: 5.1.0.2 → 5.1.1.1
   └─ PATCH incremented
   
3. Logged as "template_update" in changelog
   
4. Next app run: BUILD increments
   └─ 5.1.1.1 → 5.1.1.2
```

### Scenario 3: Emergency Restart
```
1. Something breaks during use
   
2. Go to Admin & Deploy tab
   
3. Click "🔁 Restart Streamlit Only"
   └─ Clears session
   └─ Resets user state
   
4. Version: 5.1.1.5 → 5.1.1.6
   └─ Logged as "restart"
```

---

## 📊 Version Tracking

### File Structure
```
project/
├── app.py                          ← Application code
├── version.json                    ← Version info (auto-managed)
├── changelog.json                  ← Change log (auto-managed)
├── streamlit_service.sh            ← Service manager script
├── streamlit.log                   ← Application logs
├── streamlit.pid                   ← Process ID
├── sheet_templates.json            ← Template configurations
├── custom_templates.json           ← User custom configs
└── README.md                       ← This file
```

### Version JSON Format
```json
{
  "major": 5,
  "minor": 1,
  "patch": 2,
  "build": 45,
  "created": "2024-06-12T10:00:00",
  "last_modified": "2024-06-12T14:30:00",
  "app_hash": "abc123def456...",
  "config_hash": "def456ghi789...",
  "templates_hash": "ghi789jkl012..."
}
```

### Changelog Format
```json
[
  {
    "timestamp": "2024-06-12T14:30:00",
    "type": "code_update",
    "description": "Auto-version bump: App code modified",
    "details": "",
    "version": "v5.1.0.1",
    "user": "system"
  }
]
```

---

## 🚀 Service Management

### Using Bash Script
```bash
# Start service
./streamlit_service.sh start

# Stop service
./streamlit_service.sh stop

# Restart service
./streamlit_service.sh restart

# Check status
./streamlit_service.sh status

# View logs (last 50 lines)
./streamlit_service.sh logs

# Follow logs in real-time
./streamlit_service.sh follow
```

### Using Systemd (Production)
```bash
# Install service
sudo cp excel-exporter.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable excel-exporter

# Start/stop/restart
sudo systemctl start excel-exporter
sudo systemctl stop excel-exporter
sudo systemctl restart excel-exporter

# Check status
sudo systemctl status excel-exporter

# View logs
sudo journalctl -u excel-exporter -f
```

### Using Docker (Optional)
```dockerfile
FROM python:3.9-slim

WORKDIR /app
COPY requirements.txt .
RUN pip install -r requirements.txt

COPY . .

EXPOSE 8501
CMD ["streamlit", "run", "app.py"]
```

---

## 🔐 Security

### Default Credentials
```
Username: admin
Password: PaSSw0rd@1
```

⚠️ **CHANGE THESE BEFORE PRODUCTION!**

Edit in app.py:
```python
ADMIN_USERNAME = "your_username"
ADMIN_PASSWORD = "your_secure_password"
```

### Recommended Security Measures
- [ ] Change default credentials
- [ ] Use HTTPS/SSL in production
- [ ] Restrict network access
- [ ] Regular backups of version.json & changelog.json
- [ ] Monitor systemd logs
- [ ] Set up firewall rules

---

## 📖 Documentation Files

| File | Purpose |
|------|---------|
| **README.md** | This file (overview) |
| **QUICK_START.md** | Getting started guide |
| **VERSION_MANAGEMENT_GUIDE.md** | Complete version documentation |
| **streamlit_service.sh** | Service management script |
| **excel-exporter.service** | Systemd service file |

---

## 🛠️ Configuration

### GitHub Integration
Edit `GITHUB_CONFIG` in app.py:
```python
GITHUB_CONFIG = {
    'repo_url': 'https://github.com/your-org/excel-exporter.git',
    'branch': 'main',
    'enabled': True  # Set to True to enable
}
```

### Streamlit Settings
Edit streamlit_service.sh:
```bash
PORT=8501                    # Streamlit port
HOST=0.0.0.0               # Listen address
LOG_FILE="streamlit.log"    # Log file path
PID_FILE="streamlit.pid"    # PID file path
```

### Environment Variables
```bash
export PORT=8501
export HOST=0.0.0.0
export GITHUB_BRANCH=main
export PYTHONUNBUFFERED=1
```

---

## 📊 Monitoring & Logging

### Application Logs
```bash
# View recent logs
./streamlit_service.sh logs

# Follow in real-time
./streamlit_service.sh follow

# Search for errors
grep "ERROR" streamlit.log

# View Git operations
grep "git_pull\|git_push" changelog.json
```

### Version Tracking
```bash
# Current version
cat version.json | jq .

# Recent changes
cat changelog.json | jq '.[0:10]'

# Changes by type
cat changelog.json | jq '.[] | select(.type=="code_update")'
```

---

## 🐛 Troubleshooting

### Port Already in Use
```bash
# Find process using port 8501
lsof -i :8501

# Kill process
kill -9 <PID>

# Or use different port
streamlit run app.py --server.port 8502
```

### Git Commands Failing
```bash
# Check git installation
git --version

# Check repository status
git status

# Verify credentials
git config --list

# Test connection
git fetch --dry-run
```

### Application Not Starting
```bash
# Check Python installation
python --version

# Install dependencies
pip install -r requirements.txt

# Run directly to see errors
streamlit run app.py

# Check logs
./streamlit_service.sh logs
```

### Version Not Incrementing
```bash
# Check version.json exists
ls -la version.json

# Verify file hashes are calculated
cat version.json | jq '.app_hash'

# Force restart
./streamlit_service.sh restart
```

---

## 📈 Performance Tips

### Optimize Excel Generation
- Filter data before export
- Use separate files for large datasets
- Enable subtotals only when needed

### Optimize Memory Usage
```bash
# Limit memory (systemd)
MemoryLimit=512M

# Limit CPU usage (systemd)
CPUQuota=50%
```

### Optimize Network
- Use local Git repository for faster pulls
- Cache frequently accessed data
- Implement data compression

---

## 🔄 Update Procedure

### Update Code
```bash
1. Pull latest from GitHub
   ./streamlit_service.sh stop
   git pull origin main
   ./streamlit_service.sh start

2. OR use in-app deployment
   Go to Admin & Deploy → Click "Git Pull + Restart"
```

### Update Dependencies
```bash
pip install --upgrade streamlit pandas openpyxl
```

### Backup Data
```bash
# Before updates
cp version.json version.json.bak
cp changelog.json changelog.json.bak
cp -r . ../backup-$(date +%Y%m%d)
```

---

## 🤝 Support & Contribution

### Get Help
1. Check logs: `./streamlit_service.sh logs`
2. Review changelog: `cat changelog.json`
3. Read documentation: `VERSION_MANAGEMENT_GUIDE.md`
4. Check version info: `cat version.json`

### Report Issues
Include:
- Current version: `cat version.json | jq '.major, .minor, .patch, .build'`
- Recent logs: `tail -50 streamlit.log`
- Git status: `git status`
- Error message

---

## 📝 License

Proprietary - All Rights Reserved

---

## 🎉 Quick Links

| Link | Purpose |
|------|---------|
| [Quick Start](QUICK_START.md) | Get started in 5 minutes |
| [Version Guide](VERSION_MANAGEMENT_GUIDE.md) | Complete version documentation |
| [Service Script](streamlit_service.sh) | Service management |
| [Systemd Service](excel-exporter.service) | Production systemd service |

---

## 📞 Changelog Summary

### v5.0.0 - Initial Release
- ✨ Automatic version management
- 🚀 Git integration & deployment
- 📊 Real-time changelog
- 🛠️ Admin control panel
- 🔍 File change detection
- 📱 Mobile-responsive UI

### v5.0+ Updates
- Regular builds (automatic)
- Continuous improvement
- Bug fixes and optimizations

---

**Built with ❤️ for Excel & Streamlit enthusiasts**

*Last Updated: June 2024*
