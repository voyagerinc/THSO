"""
Excel Master File & Template Exporter - v5.0+ FIXED
AUTO-VERSION MANAGEMENT + GIT DEPLOY
"""

# ============================================================================
# 🔴 STEP 1: IMPORTS (MUST BE FIRST)
# ============================================================================
import streamlit as st
import pandas as pd
import numpy as np
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.utils.dataframe import dataframe_to_rows
import io
import json
import os
from datetime import datetime
import zipfile
import subprocess
import sys
import time
import hashlib

# ============================================================================
# 🔴 STEP 2: ALL CONSTANTS (MUST BE BEFORE FUNCTIONS & CODE)
# ============================================================================
VERSION_FILE = "version.json"
CHANGELOG_FILE = "changelog.json"
TEMPLATES_FILE = "sheet_templates.json"
CUSTOM_TEMPLATES_FILE = "custom_templates.json"
ADMIN_USERNAME = "admin"
ADMIN_PASSWORD = "PaSSw0rd@1"

GITHUB_CONFIG = {
    'repo_url': 'https://github.com/your-username/excel-exporter.git',
    'branch': 'main',
    'enabled': False
}

# ============================================================================
# 🔴 STEP 3: HELPER FUNCTIONS (Safe functions only)
# ============================================================================
def safe_read_json(filepath):
    """Safely read JSON file"""
    try:
        if os.path.exists(filepath):
            with open(filepath, 'r') as f:
                return json.load(f)
    except:
        pass
    return None

def safe_write_json(filepath, data):
    """Safely write JSON file"""
    try:
        with open(filepath, 'w') as f:
            json.dump(data, f, indent=2)
        return True
    except:
        return False

def get_file_hash(file_path):
    """Get SHA256 hash of a file"""
    try:
        if not os.path.exists(file_path):
            return None
        sha256_hash = hashlib.sha256()
        with open(file_path, "rb") as f:
            for byte_block in iter(lambda: f.read(4096), b""):
                sha256_hash.update(byte_block)
        return sha256_hash.hexdigest()
    except:
        return None

# ============================================================================
# 🔴 STEP 4: VERSION FUNCTIONS
# ============================================================================
def load_version_info():
    """Load version info from file"""
    data = safe_read_json(VERSION_FILE)
    if data:
        return data
    
    return {
        "major": 5,
        "minor": 0,
        "patch": 0,
        "build": 1,
        "created": datetime.now().isoformat(),
        "last_modified": datetime.now().isoformat(),
        "app_hash": get_file_hash(__file__),
        "config_hash": None,
        "templates_hash": None
    }

def save_version_info(version_info):
    """Save version info"""
    return safe_write_json(VERSION_FILE, version_info)

def load_changelog():
    """Load changelog"""
    data = safe_read_json(CHANGELOG_FILE)
    return data if data else []

def save_changelog(changelog):
    """Save changelog"""
    return safe_write_json(CHANGELOG_FILE, changelog)

def get_version_string():
    """Get version string"""
    try:
        if 'version_info' in st.session_state:
            v = st.session_state.version_info
            return f"v{v['major']}.{v['minor']}.{v['patch']}.{v['build']}"
    except:
        pass
    return "v5.0.0.1"

def check_for_changes():
    """Check if files changed (SAFE VERSION)"""
    try:
        if 'version_info' not in st.session_state:
            return False, []
        
        version_info = st.session_state.version_info
        changed = False
        change_list = []
        
        # Check app.py
        app_hash = get_file_hash(__file__)
        if app_hash and app_hash != version_info.get('app_hash'):
            changed = True
            change_list.append("App code modified")
            version_info['app_hash'] = app_hash
        
        # Check templates
        if os.path.exists(TEMPLATES_FILE):
            template_hash = get_file_hash(TEMPLATES_FILE)
            if template_hash and template_hash != version_info.get('templates_hash'):
                changed = True
                change_list.append("Templates modified")
                version_info['templates_hash'] = template_hash
        
        # Check config
        if os.path.exists(CUSTOM_TEMPLATES_FILE):
            config_hash = get_file_hash(CUSTOM_TEMPLATES_FILE)
            if config_hash and config_hash != version_info.get('config_hash'):
                changed = True
                change_list.append("Configuration modified")
                version_info['config_hash'] = config_hash
        
        return changed, change_list
    except Exception as e:
        return False, []

def increment_version(version_info, change_list):
    """Increment version"""
    try:
        if change_list:
            if any('code' in c.lower() for c in change_list):
                version_info['minor'] += 1
                version_info['patch'] = 0
                version_info['build'] = 1
            else:
                version_info['patch'] += 1
                version_info['build'] = 1
        else:
            version_info['build'] += 1
        
        version_info['last_modified'] = datetime.now().isoformat()
        save_version_info(version_info)
    except:
        pass

def add_changelog_entry(change_type, description, details=""):
    """Add changelog entry"""
    try:
        changelog = load_changelog()
        entry = {
            "timestamp": datetime.now().isoformat(),
            "type": change_type,
            "description": description,
            "details": details,
            "version": get_version_string(),
            "user": "system"
        }
        changelog.insert(0, entry)
        changelog = changelog[:100]
        save_changelog(changelog)
    except:
        pass

# ============================================================================
# 🔴 STEP 5: STREAMLIT PAGE CONFIG
# ============================================================================
st.set_page_config(page_title="Excel Master & Template Exporter", layout="wide")

# ============================================================================
# 🔴 STEP 6: INITIALIZE SESSION STATE
# ============================================================================
if 'version_info' not in st.session_state:
    st.session_state.version_info = load_version_info()

# ============================================================================
# 🔴 STEP 7: CHECK VERSION (WRAPPED IN TRY-EXCEPT)
# ============================================================================
try:
    changed, change_list = check_for_changes()
    if changed:
        increment_version(st.session_state.version_info, change_list)
except Exception as e:
    pass  # Silently skip if version check fails

# ============================================================================
# GIT FUNCTIONS
# ============================================================================
def get_current_branch():
    """Get current Git branch"""
    try:
        result = subprocess.run(['git', 'rev-parse', '--abbrev-ref', 'HEAD'],
                              capture_output=True, text=True, timeout=10)
        return result.stdout.strip() if result.returncode == 0 else "unknown"
    except:
        return "unknown"

def get_current_commit():
    """Get current Git commit"""
    try:
        result = subprocess.run(['git', 'rev-parse', '--short', 'HEAD'],
                              capture_output=True, text=True, timeout=10)
        return result.stdout.strip() if result.returncode == 0 else "unknown"
    except:
        return "unknown"

def get_uncommitted_changes():
    """Get uncommitted changes count"""
    try:
        result = subprocess.run(['git', 'status', '--porcelain'],
                              capture_output=True, text=True, timeout=10)
        return len(result.stdout.strip().split('\n')) if result.stdout.strip() else 0
    except:
        return 0

def sync_with_github():
    """Sync with GitHub"""
    try:
        progress_bar = st.progress(0)
        status_text = st.empty()
        
        status_text.text("🔄 Fetching from GitHub...")
        progress_bar.progress(25)
        
        subprocess.run(['git', 'fetch', 'origin', GITHUB_CONFIG['branch']],
                      capture_output=True, text=True, timeout=30)
        
        progress_bar.progress(50)
        status_text.text("📥 Pulling latest changes...")
        
        result = subprocess.run(['git', 'pull', 'origin', GITHUB_CONFIG['branch']],
                              capture_output=True, text=True, timeout=30)
        
        progress_bar.progress(100)
        
        if result.returncode == 0:
            add_changelog_entry("git_pull", "Pulled from GitHub")
            st.success("✅ GitHub sync successful!")
            st.balloons()
            return True
        else:
            st.error(f"❌ Git pull failed")
            return False
    except Exception as e:
        st.error(f"❌ Error: {str(e)}")
        return False

def restart_streamlit():
    """Restart Streamlit"""
    try:
        status_text = st.empty()
        progress_bar = st.progress(0)
        
        status_text.text("🔄 Restarting...")
        progress_bar.progress(50)
        
        add_changelog_entry("restart", "Streamlit restarted")
        
        status_text.text("🚀 Restart in progress...")
        progress_bar.progress(100)
        
        st.success("✅ Restarting application...")
        time.sleep(2)
        st.rerun()
    except Exception as e:
        st.error(f"❌ Error: {str(e)}")

def git_pull_and_restart():
    """Git pull + restart"""
    try:
        st.info("⏳ Starting deployment...")
        
        if not sync_with_github():
            st.error("❌ Git pull failed")
            return False
        
        st.success("✅ Code updated!")
        time.sleep(1)
        
        st.info("🚀 Restarting Streamlit...")
        add_changelog_entry("git_pull_restart", "Git pull + Streamlit restart")
        
        time.sleep(2)
        st.rerun()
        return True
    except Exception as e:
        st.error(f"❌ Error: {str(e)}")
        return False

def push_to_github(message):
    """Push to GitHub"""
    try:
        progress_bar = st.progress(0)
        status_text = st.empty()
        
        status_text.text("📝 Staging...")
        progress_bar.progress(25)
        
        subprocess.run(['git', 'add', '.'], capture_output=True, timeout=10)
        
        progress_bar.progress(50)
        status_text.text("💾 Committing...")
        
        subprocess.run(['git', 'commit', '-m', message],
                      capture_output=True, timeout=10)
        
        progress_bar.progress(75)
        status_text.text("📤 Pushing...")
        
        result = subprocess.run(['git', 'push', 'origin', GITHUB_CONFIG['branch']],
                              capture_output=True, text=True, timeout=30)
        
        progress_bar.progress(100)
        
        if result.returncode == 0:
            add_changelog_entry("git_push", f"Pushed to GitHub: {message}")
            st.success("✅ Pushed to GitHub!")
            st.balloons()
            return True
        else:
            st.error("❌ Push failed")
            return False
    except Exception as e:
        st.error(f"❌ Error: {str(e)}")
        return False

# ============================================================================
# TEMPLATE FUNCTIONS
# ============================================================================
def load_sheet_templates():
    """Load templates"""
    data = safe_read_json(TEMPLATES_FILE)
    if data:
        return data
    return {
        "All Records": {"filter_type": "none", "filter_value": "", "columns": 13, "enabled": True, "description": "All records"},
        "Yesterday": {"filter_type": "date", "filter_value": "yesterday", "columns": 13, "enabled": True, "description": "Yesterday"},
        "This Month": {"filter_type": "date", "filter_value": "this_month", "columns": 13, "enabled": True, "description": "This month"},
    }

def load_custom_templates():
    """Load custom templates"""
    data = safe_read_json(CUSTOM_TEMPLATES_FILE)
    return data if data else {}

def save_sheet_templates(templates):
    """Save templates"""
    if safe_write_json(TEMPLATES_FILE, templates):
        add_changelog_entry("template_update", f"Templates updated")
        return True
    return False

def save_custom_templates(templates):
    """Save custom templates"""
    if safe_write_json(CUSTOM_TEMPLATES_FILE, templates):
        add_changelog_entry("custom_template_update", f"Custom templates updated")
        return True
    return False

# Initialize templates
if 'sheet_templates' not in st.session_state:
    st.session_state['sheet_templates'] = load_sheet_templates()
if 'custom_templates' not in st.session_state:
    st.session_state['custom_templates'] = load_custom_templates()

# ============================================================================
# SAMPLE DATA
# ============================================================================
def generate_sample_data():
    """Generate sample data"""
    np.random.seed(42)
    dates = pd.date_range(start='2024-01-01', periods=100, freq='D')
    return pd.DataFrame({
        'Date': np.random.choice(dates, 500),
        'Line': np.random.choice(['L1', 'L2', 'L3'], 500),
        'Product': np.random.choice(['P1', 'P2', 'P3'], 500),
        'Sales_Person': np.random.choice(['Alice', 'Bob', 'Charlie'], 500),
        'Amount': np.random.randint(1000, 10000, 500),
    })

# ============================================================================
# AUTHENTICATION
# ============================================================================
def check_login():
    return st.session_state.get('logged_in', False)

def login_page():
    st.title("🔐 Login Required")
    st.markdown(f"Excel Master & Template Exporter {get_version_string()}")
    
    with st.form("login_form"):
        username = st.text_input("Username")
        password = st.text_input("Password", type="password")
        submit = st.form_submit_button("Login", type="primary")
        
        if submit:
            if username == ADMIN_USERNAME and password == ADMIN_PASSWORD:
                st.session_state['logged_in'] = True
                st.success("Login successful!")
                st.rerun()
            else:
                st.error("Invalid username or password")

if not check_login():
    login_page()
    st.stop()

# ============================================================================
# MAIN UI
# ============================================================================
st.title("📊 Excel Master & Template Exporter")

# Version badge
with st.expander(f"ℹ️ **Version {get_version_string()} | Build {st.session_state.version_info['build']}**", expanded=False):
    col1, col2, col3, col4 = st.columns(4)
    with col1:
        st.metric("Version", f"{st.session_state.version_info['major']}.{st.session_state.version_info['minor']}.{st.session_state.version_info['patch']}")
    with col2:
        st.metric("Build", st.session_state.version_info['build'])
    with col3:
        st.metric("Branch", get_current_branch())
    with col4:
        st.metric("Commit", get_current_commit()[:8])
    
    st.divider()
    st.markdown("**Recent Changes:**")
    changelog = load_changelog()[:5]
    for entry in changelog:
        st.caption(f"🔹 {entry['description']} ({entry['type']})")

# Tabs
tab1, tab2, tab3, tab_admin = st.tabs(["📁 Export", "⚙️ Templates", "📋 Custom", "🛠️ Deploy"])

# ============================================================================
# TAB 1: EXPORT
# ============================================================================
with tab1:
    st.subheader("📁 Generate Master File")
    if st.button("🎯 Generate", type="primary", use_container_width=True):
        st.session_state['master_file'] = generate_sample_data()
        add_changelog_entry("export", "Master file generated")
        st.success(f"✅ Generated {len(st.session_state['master_file'])} rows")

# ============================================================================
# TAB 2: TEMPLATES
# ============================================================================
with tab2:
    st.subheader("⚙️ Manage Templates")
    
    col1, col2 = st.columns([1, 1])
    with col1:
        sheet = st.selectbox("Select Template", list(st.session_state['sheet_templates'].keys()))
        config = st.session_state['sheet_templates'][sheet]
        
        new_desc = st.text_input("Description", value=config.get('description', ''))
        new_enabled = st.checkbox("Enabled", value=config.get('enabled', True))
        
        if st.button("💾 Save", type="primary", use_container_width=True):
            st.session_state['sheet_templates'][sheet]['description'] = new_desc
            st.session_state['sheet_templates'][sheet]['enabled'] = new_enabled
            save_sheet_templates(st.session_state['sheet_templates'])
            st.success("✅ Saved!")
            st.rerun()
    
    with col2:
        st.markdown("**Current Templates:**")
        for name, cfg in st.session_state['sheet_templates'].items():
            status = "✅" if cfg.get('enabled') else "❌"
            st.write(f"{status} {name}")

# ============================================================================
# TAB 3: CUSTOM
# ============================================================================
with tab3:
    st.subheader("📁 Custom Templates")
    
    c_name = st.text_input("Template Name")
    if st.button("💾 Create", type="primary", use_container_width=True):
        if c_name:
            st.session_state['custom_templates'][c_name] = {}
            save_custom_templates(st.session_state['custom_templates'])
            st.success(f"✅ Created '{c_name}'")
            st.rerun()

# ============================================================================
# TAB 4: ADMIN & DEPLOY
# ============================================================================
with tab_admin:
    st.subheader("🛠️ Admin & Deployment")
    
    col1, col2 = st.columns([1, 1])
    
    with col1:
        st.markdown("### 🚀 Operations")
        
        if st.button("🔄 Git Pull + Restart", use_container_width=True, type="primary"):
            git_pull_and_restart()
        
        if st.button("📥 Git Pull Only", use_container_width=True):
            sync_with_github()
        
        if st.button("🔁 Restart Only", use_container_width=True):
            restart_streamlit()
        
        st.divider()
        
        msg = st.text_input("Commit message", "Update from Excel Exporter")
        if st.button("📤 Push to GitHub", use_container_width=True):
            push_to_github(msg)
    
    with col2:
        st.markdown("### 📊 Status")
        
        v = st.session_state.version_info
        st.write(f"**Version:** v{v['major']}.{v['minor']}.{v['patch']}.{v['build']}")
        st.write(f"**Branch:** {get_current_branch()}")
        st.write(f"**Commit:** {get_current_commit()}")
        
        changes = get_uncommitted_changes()
        if changes > 0:
            st.warning(f"⚠️ {changes} files with changes")
        else:
            st.success("✅ Clean")
        
        st.divider()
        st.markdown("**Changelog (Last 5):**")
        for entry in load_changelog()[:5]:
            st.caption(f"🔹 {entry['description']}")

# ============================================================================
# FOOTER
# ============================================================================
st.divider()
col1, col2, col3 = st.columns([1, 1, 1])
with col1:
    st.caption(f"Version: {get_version_string()}")
with col2:
    st.caption(f"Build: {st.session_state.version_info['build']}")
with col3:
    st.caption(f"Branch: {get_current_branch()}")
